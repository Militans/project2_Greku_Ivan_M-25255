import prompt


def welcome() -> None:
    print("Первая попытка запустить проект!")
    print()
    print("***")
    print("<command> exit - выйти из программы")
    print("<command> help - справочная информация")

    while True:
        command = prompt.string("Введите команду: ").strip()

        match command:
            case "help":
                print()
                print("<command> exit - выйти из программы")
                print("<command> help - справочная информация")
            case "exit":
                return
            case _:
                # по ТЗ можно просто снова спрашивать
                # (можно ещё написать "Неизвестная команда", но не обязательно)
                continue
